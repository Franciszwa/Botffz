# 777BOT.py  (شبیه‌سازی + اجرای واقعی main.py + PID)
# نیازمند: python-telegram-bot==20.3
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, filters,
    ContextTypes, CallbackQueryHandler
)
import os, json, time, subprocess, random, signal

# ---------------- تنظیمات اصلی ----------------
BOT_TOKEN = "8395388869:AAG6nwbi80Gwpy56Uu-ehTSAFmXCan29G2M"
OWNER_ID = 7225047465
CREATOR_USERNAME = "@Franciszw"
LICENSE_CODE = "777"

SCRIPT_PATH = "/storage/emulated/0/777/main.py"
LOG_FILE = "/storage/emulated/0/new_premium_bot_run.log"
PENDING_FILE = "pending.json"
APPROVED_FILE = "approved.json"
STATUS_FILE = "/storage/emulated/0/777/status.json"
PID_FILE = "/data/data/com.termux/files/home/.bot_script_run.pid"
# -------------------------------------------------------------------------

def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("save_json error:", e)

def write_pidfile(pid):
    try:
        os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
        with open(PID_FILE, "w") as f:
            f.write(str(pid))
    except Exception as e:
        print("write_pidfile error:", e)

def read_pidfile():
    try:
        with open(PID_FILE, "r") as f:
            return int(f.read().strip())
    except Exception:
        return None

def remove_pidfile():
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception:
        pass

def set_status(active: bool):
    try:
        os.makedirs(os.path.dirname(STATUS_FILE), exist_ok=True)
        with open(STATUS_FILE, "w", encoding="utf-8") as f:
            json.dump({"active": active}, f)
    except Exception as e:
        print("set_status error:", e)

def get_status():
    try:
        with open(STATUS_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("active", True)
    except Exception:
        return True

user_states = {}

def write_log_sim(msg):
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{int(time.time())} | {msg}\n")
    except Exception as e:
        print("write_log_sim error:", e)

def simulate_and_log_friend_request(ffid, by_user_id):
    write_log_sim(f"SIMULATION START for FFID={ffid} by TG {by_user_id}")
    steps = [
        f"It was successful✅: {ffid}",
        f"-> جستجو برای آیدی {ffid} در بازی ...",
        f"-> اکانت پیدا شد .",
        f"-> ارسال درخواست دوستی به {ffid} انجام شد ."
    ]
    for s in steps:
        write_log_sim(s)
    write_log_sim("SIMULATION END")
    return {
        "simulated": True,
        "messages": steps,
        "real_attempt": False,
        "real_result": "777BOT.PY..."
    }

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user_states[uid] = None
    await update.message.reply_text("license code :\n🆔 @Franciszw\n\n")

async def cmd_off(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("⛔ فقط صاحب ربات می‌تواند این دستور را بزند.")
    set_status(False)
    await update.message.reply_text("🔴 اسکریپت غیرفعال شد (در حالت انتظار).")

async def cmd_on(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("⛔ فقط صاحب ربات می‌تواند این دستور را بزند.")
    set_status(True)
    await update.message.reply_text("🟢 اسکریپت دوباره فعال شد.")

async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = query.from_user.id
    if query.data in ("send_ffid","activate"):
        user_states[uid] = "waiting_for_ffid"
        await query.edit_message_text("لطفاً آیدی عددی Free Fire خود را ارسال کنید:")

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    text = update.message.text.strip()
    state = user_states.get(uid)

    if state is None:
        if text == LICENSE_CODE:
            user_states[uid] = "licensed"
            kb = InlineKeyboardMarkup([[InlineKeyboardButton("🟢 فرستادن آیدی Free Fire", callback_data="send_ffid")]])
            await update.message.reply_text("✅ لایسنس معتبر است.\nبرای ارسال آیدی روی دکمه بزنید.", reply_markup=kb)
        else:
            await update.message.reply_text("❌ لایسنس اشتباه است، دوباره امتحان کن.")
        return

    if state in ("licensed", "waiting_for_ffid"):
        ffid = text
        user_states[uid] = "waiting_approval"
        await update.message.reply_text("درخواست شما ثبت شد، در حال بررسی و اجرای عملیات...\n" + CREATOR_USERNAME)

        pending = load_json(PENDING_FILE)
        pending[str(uid)] = {
            "tg_id": uid,
            "tg_username": update.effective_user.username or "",
            "first_name": update.effective_user.first_name or "",
            "ff_id": ffid,
            "ts": int(time.time())
        }
        save_json(PENDING_FILE, pending)

        owner_msg = (
            f"📩 درخواست فعال‌سازی جدید (شبیه‌سازی):\n\n"
            f"👤 نام: {update.effective_user.first_name} @{update.effective_user.username or ''}\n"
            f"🆔 تلگرام: {uid}\n"
            f"🎮 آیدی Free Fire: {ffid}\n\n"
            f"برای تأیید: /approve {uid}\nبرای رد: /reject {uid}\n"
        )
        try:
            await context.bot.send_message(OWNER_ID, owner_msg)
        except Exception as e:
            print("send to owner error:", e)
        return

    await update.message.reply_text("برای شروع از /start استفاده کنید.\n" + CREATOR_USERNAME)

async def approve_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("⛔ دسترسی ندارید.")
    if not context.args:
        return await update.message.reply_text("مثال: /approve 123456789")
    try:
        target = int(context.args[0])
    except:
        return await update.message.reply_text("آیدی نامعتبر.")
    pending = load_json(PENDING_FILE)
    approved = load_json(APPROVED_FILE)
    if str(target) not in pending:
        return await update.message.reply_text("درخواست پیدا نشد.")
    info = pending.pop(str(target))
    approved[str(target)] = info
    save_json(PENDING_FILE, pending)
    save_json(APPROVED_FILE, approved)
    try:
        await context.bot.send_message(target, "✅ درخواست شما تایید شد. اکنون می‌توانید /777 را ارسال کنید.\n" + CREATOR_USERNAME)
    except Exception as e:
        print("notify approved user error:", e)
    await update.message.reply_text(f"کاربر {target} تایید شد ✅")

async def reject_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("⛔ دسترسی ندارید.")
    if not context.args:
        return await update.message.reply_text("مثال: /reject 123456789")
    try:
        target = int(context.args[0])
    except:
        return await update.message.reply_text("آیدی نامعتبر.")
    pending = load_json(PENDING_FILE)
    if str(target) in pending:
        pending.pop(str(target))
        save_json(PENDING_FILE, pending)
    try:
        await context.bot.send_message(target, "متاسفانه درخواست شما رد شد. با سازنده تماس بگیرید.\n" + CREATOR_USERNAME)
    except:
        pass
    await update.message.reply_text(f"کاربر {target} رد شد ❌")

# ✅ اصلاح شده: جلوگیری از اجرای چندباره main.py
async def run_777_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not get_status():
        return await update.message.reply_text("🔴 ربات درحال اپدیت ... فقط صاحب ربات در زمان اپدیت به این بخش دسترسی دارد.\n" + CREATOR_USERNAME)

    approved = load_json(APPROVED_FILE)
    if str(uid) not in approved:
        return await update.message.reply_text("❌ شما تأیید نشده‌اید. ابتدا /start را بزنید و منتظر تایید بمانید.\n" + CREATOR_USERNAME)

    pid = read_pidfile()
    if pid:
        try:
            os.kill(pid, 0)
            return await update.message.reply_text(
                f"⚠️ فرایند قبلی (PID={pid}) هنوز در حال اجراست.\n"
                f"\n" + CREATOR_USERNAME
            )
        except OSError:
            remove_pidfile()

    info = approved[str(uid)]
    ffid = info.get("ff_id", "N/A")

    await update.message.reply_text(f"✅ اجرای شروع شد برای آیدی: {ffid}\n(777BOT.py)\n" + CREATOR_USERNAME)

    sim = simulate_and_log_friend_request(ffid, uid)
    for line in sim["messages"]:
        time.sleep(0.4)
        await update.message.reply_text(line)

    try:
        process = subprocess.Popen(["python", SCRIPT_PATH])
        pid = process.pid
        write_pidfile(pid)
        await update.message.reply_text(f"📄 main.py اجرا شد (PID={pid})")
    except Exception as e:
        await update.message.reply_text(f"❌ خطا در اجرای main.py: {e}")

    await update.message.reply_text(sim["real_result"])

async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = read_pidfile()
    running = pid is not None
    active = get_status()
    msg = "777BOT.py — Bot running ✅\n"
    msg += f"حالت فعال: {'🟢' if active else '🔴'}\n"
    msg += f"PID فعلی: {pid if running else 'هیچکدام (در حالت شبیه‌سازی)'}"
    await update.message.reply_text(msg)

async def cmd_kill(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("⛔ فقط صاحب ربات می‌تواند این دستور را بزند.")
    pid = read_pidfile()
    if not pid:
        return await update.message.reply_text("❌ هیچ main.py فعالی پیدا نشد.")
    try:
        os.kill(pid, 0)
    except OSError:
        remove_pidfile()
        return await update.message.reply_text("⚠️ هیچ پردازه‌ای فعال نبود، فایل pid پاک شد.")
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(1)
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception:
            pass
        remove_pidfile()
        set_status(False)
        await update.message.reply_text(f"🛑 فایل main.py با PID {pid} به طور کامل متوقف شد.")
    except Exception as e:
        await update.message.reply_text(f"⚠️ خطا در توقف main.py:\n{e}")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(callback_router, pattern="^(send_ffid|activate)$"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(CommandHandler("approve", approve_cmd))
    app.add_handler(CommandHandler("reject", reject_cmd))
    app.add_handler(CommandHandler("777", run_777_cmd))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("off", cmd_off))
    app.add_handler(CommandHandler("on", cmd_on))
    app.add_handler(CommandHandler("kill", cmd_kill))

    print("777BOT.py started (simulation + real main.py + PID)...")
    app.run_polling()

if __name__ == "__main__":
    main()